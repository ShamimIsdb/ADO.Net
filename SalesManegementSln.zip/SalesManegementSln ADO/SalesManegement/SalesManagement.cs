﻿using SalesManegement.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalesManegement
{
    public partial class SalesManegement : Form
    {
        string conStr = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
        int empId = 101;
        int purchaseId = 0;
        string imgName;
        string filePath = "";
        string folderPath = @"D:\ADO.net\SalesManegementSln\SalesManegement\Resources\";
        string imagePathFromData;

        public SalesManegement()
        {
            InitializeComponent();
        }
        

        private void LoadCombocustomer()
        {
            string sqlQuery = "SELECT * FROM Customer";
            SqlConnection con = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand(sqlQuery, con);
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader, LoadOption.Upsert);
            if (dt != null)
            {
                cmbCustomer.DisplayMember = "CustomerName";
                cmbCustomer.ValueMember = "CustomerId";
                cmbCustomer.DataSource = dt;
            }
            con.Close();
        }

        private void LoadComboproduct()
        {
            string sqlQuery = "SELECT * FROM Product";
            SqlConnection con = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand(sqlQuery, con);
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader, LoadOption.Upsert);
            if (dt != null)
            {
                cmbProductName.DisplayMember = "ProductName";
                cmbProductName.ValueMember = "ProductId";
                cmbProductName.DataSource = dt;
            }
            con.Close();
        }

        private void LoadEmployeeName()
        {
            string userName = "";
            string sqlQuery = "SELECT FullName FROM Employee WHERE EmployeeId='" + empId + "'";
            SqlConnection con = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand(sqlQuery, con);
            con.Open();
            userName = (cmd.ExecuteScalar()).ToString();
            if (userName == "")
            {
                lblEmployeeName.Text = "Unknown";
            }
            lblEmployeeName.Text = userName;
            con.Close();
        }

       

        private void ClearMethod()
        {
            txtProduct.Text = "";
            txtCustomer.Text = "";
            cmbProductName.Text = "";
            cmbCustomer.Text = "";
            txtVoucherNo.Text = "";
            txtUnitPrice.Text = "";
            txtQuantity.Text = "";
            pbProduct.Image = Resources.noimage;
            ShowTotalAmount();
        }

        private void ShowTotalAmount()
        {

            string sqlQuery = "SELECT SUM(TotalPrice) AS TotalAmount FROM Sales";
            SqlConnection con = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand(sqlQuery, con);
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                lblTotalAmount.Text = reader["TotalAmount"].ToString();
            }
            else
            {
                lblTotalAmount.Text = "00.00";
            }
            con.Close();
        }

       

        

        private void LoadGridView()
        {
            ShowImageInGrideView();
            //string sqlQuery = "SELECT pu.VoucherNo, pu.SaleDate, pu.Quantity, pu.TotalPrice, po.ProductName, su.CustomerName, em.EmployeeName FROM Sales pu JOIN Product po ON pu.ProductId=po.ProductId JOIN Customer su ON pu.CustomerId=su.CustomerId JOIN Employee em ON pu.EmployeeId=em.EmployeeId";
            //SqlConnection con = new SqlConnection(conStr);
            //SqlDataAdapter sda = new SqlDataAdapter(sqlQuery, con);
            //DataTable dt = new DataTable();
            //sda.Fill(dt);
            //dgvSale.RowTemplate.Height = 30;
            //dgvSale.DataSource = dt;
            //dgvSale.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        

       

       
        private void ShowImageInGrideView()
        {
            string sqlQuery = "SELECT pu.SaleId, pu.VoucherNo, pu.SaleDate, pu.Quantity, pu.TotalPrice, po.ProductName, su.CustomerName, em.FullName,pu.ImageUrl FROM Sales pu JOIN Product po ON pu.ProductId=po.ProductId JOIN Customer su ON pu.CustomerId=su.CustomerId JOIN Employee em ON pu.EmployeeId=em.EmployeeId\r\n";
            SqlConnection con = new SqlConnection(conStr);
            SqlDataAdapter sda = new SqlDataAdapter(sqlQuery, con);
            DataTable dt = new DataTable();
            con.Open();
            sda.Fill(dt);
            dt.Columns.Add("Picture", Type.GetType("System.Byte[]"));
            foreach (DataRow dr in dt.Rows)
            {
                try
                {
                    dr["Picture"] = File.ReadAllBytes(dr["ImageUrl"].ToString());
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);
                }
            }
            con.Close();
            dgvSale.RowTemplate.Height = 52;
            dgvSale.DataSource = dt;
            DataGridViewImageColumn dgvImage = new DataGridViewImageColumn();
            dgvImage = (DataGridViewImageColumn)dgvSale.Columns[9];
            dgvImage.ImageLayout = DataGridViewImageCellLayout.Stretch;
            dgvSale.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }
      
        private void btnCourseAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtProduct.Text) == true)
            {
                txtProduct.Focus();
                errorProvider1.SetError(this.txtProduct, "Please Enter productName");
                ClearMethod();
            }
            else
            {
                Product objProduct = new Product();
                objProduct.ProductName = txtProduct.Text;
                string sqlQuery = "Insert INTO Product (ProductName) VALUES ('" + objProduct.ProductName + "')";
                SqlConnection con = new SqlConnection(conStr);
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                con.Open();
                int rowCount = cmd.ExecuteNonQuery();
                if (rowCount > 0)
                {
                    MessageBox.Show("Product added successfully!", "Success", MessageBoxButtons.OK);
                    ClearMethod();
                }
                else
                {
                    MessageBox.Show("Product Insertion failed!", "Failure", MessageBoxButtons.OK);
                    ClearMethod();
                }
                con.Close();
                LoadComboproduct();

            }
        }

        private void btnSaveCustomer_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtCustomer.Text) == true)
            {
                txtCustomer.Focus();
                errorProvider1.SetError(this.txtCustomer, "Please Enter Customer Name");
                ClearMethod();
            }
            else
            {
                Customer objCustomer = new Customer();
                objCustomer.CustomerName = txtCustomer.Text;
                string sqlQuery = "Insert INTO Customer (CustomerName) VALUES ('" + objCustomer.CustomerName + "')";
                SqlConnection con = new SqlConnection(conStr);
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                con.Open();
                int rowCount = cmd.ExecuteNonQuery();
                if (rowCount > 0)
                {
                    MessageBox.Show("Customer added successfully!", "Success", MessageBoxButtons.OK);
                    ClearMethod();
                }
                else
                {
                    MessageBox.Show("Customer Insertion failed!", "Failure", MessageBoxButtons.OK);
                    ClearMethod();
                }
                con.Close();
                LoadCombocustomer();
            }
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Image File(*.jpg; *.png; *.jpeg; *.gif; *.bmp)| *.jpg; *.png; *.jpeg; *.gif; *.bmp|all files|*.*";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                imgName = openFileDialog1.SafeFileName;
                pbProduct.Image = new Bitmap(openFileDialog1.FileName);
                filePath = openFileDialog1.FileName;
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearMethod();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            Sales objPurchase = new Sales();
            objPurchase.VoucherNo = Convert.ToInt16(txtVoucherNo.Text);
            objPurchase.SaleDate = Convert.ToDateTime(dtpSaleDate.Text);
            objPurchase.Quantity = Convert.ToInt16(txtQuantity.Text);
            decimal unitPrice =Convert.ToDecimal(txtUnitPrice.Text);
            objPurchase.TotalPrice = unitPrice * objPurchase.Quantity;
            objPurchase.ImageUrl = folderPath + Path.GetFileName(openFileDialog1.FileName);
            objPurchase.CustomerId = Convert.ToInt16(cmbCustomer.SelectedValue);           
            objPurchase.EmployeeId = empId;          
            objPurchase.ProductId = Convert.ToInt16(cmbProductName.SelectedValue);
            
            string sqlQuery = "Insert INTO Sales VALUES (@VoucherNo,@SaleDate,@Quantity,@TotalPrice,@ImageUrl,@CustomerId,@EmployeeId,@ProductId)";
            SqlConnection con = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand(sqlQuery, con);
            if (filePath == "")
            {
                cmd.Parameters.AddWithValue("@ImgUrl", "No Image Found");
            }
            else
            {
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@ImgUrl", objPurchase.ImageUrl);
                try
                {
                    File.Copy(filePath, Path.Combine(folderPath, Path.GetFileName(filePath)), true);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            
            cmd.Parameters.AddWithValue("@VoucherNo", objPurchase.VoucherNo);
            cmd.Parameters.AddWithValue("@SaleDate", objPurchase.SaleDate);
            cmd.Parameters.AddWithValue("@Quantity", objPurchase.Quantity);
            cmd.Parameters.AddWithValue("@TotalPrice", objPurchase.TotalPrice);
            cmd.Parameters.AddWithValue("@ImageUrl", objPurchase.ImageUrl);
            cmd.Parameters.AddWithValue("@ProductId", objPurchase.ProductId);
            cmd.Parameters.AddWithValue("@CustomerId", objPurchase.CustomerId);
            cmd.Parameters.AddWithValue("@EmployeeId", objPurchase.EmployeeId);
            con.Open();
            
            
            int rowCount = cmd.ExecuteNonQuery();
            if (rowCount > 0)
            {
               
                MessageBox.Show("Purchase added successfully!", "Success", MessageBoxButtons.OK);
                ClearMethod();

            }
            else
            {
                MessageBox.Show("Purchase Insertion failed!", "Failure", MessageBoxButtons.OK);
                ClearMethod();
                
            }

            con.Close();
            LoadGridView();
            ClearMethod();
            //Sales objSales = new Sales();
            //decimal unitPrice = Convert.ToDecimal(txtUnitPrice.Text);
            //objSales.CustomerId = Convert.ToInt16(cmbCustomer.SelectedValue);
            //objSales.Quantity = Convert.ToInt16(txtQuantity.Text);
            //objSales.TotalPrice = unitPrice * objSales.Quantity;
            //objSales.EmployeeId = empId;
            //objSales.VoucherNo = Convert.ToInt16(txtVoucherNo.Text);
            //objSales.SaleDate = Convert.ToDateTime(dtpSaleDate.Text);
            //objSales.ProductId = Convert.ToInt16(cmbProductName.SelectedValue);
            //objSales.ImageUrl = folderPath + Path.GetFileName(openFileDialog1.FileName);
            //string sqlQuery = "Insert INTO Sales VALUES (@VoucherNo,@SaleDate,@Quantity,@TotalPrice,@ImageUrl,@CustomerId,@EmployeeId,@ProductId)";
            //SqlConnection con = new SqlConnection(conStr);
            //SqlCommand cmd = new SqlCommand(sqlQuery, con);
            //if (filePath == "")
            //{
            //    cmd.Parameters.AddWithValue("@ImageUrl", "No Image Found");
            //}
            //else
            //{
            //    cmd.CommandType = CommandType.Text;
            //    cmd.Parameters.AddWithValue("@ImageUrl", objSales.ImageUrl);
            //    try
            //    {
            //        File.Copy(filePath, Path.Combine(folderPath, Path.GetFileName(filePath)), true);
            //    }
            //    catch (Exception ex)
            //    {
            //        MessageBox.Show(ex.Message);
            //    }
            //}
            //cmd.Parameters.AddWithValue("@VoucherNo", objSales.VoucherNo);
            //cmd.Parameters.AddWithValue("@SaleDate", objSales.SaleDate);
            //cmd.Parameters.AddWithValue("@Quantity", objSales.Quantity);
            //cmd.Parameters.AddWithValue("@TotalPrice", objSales.TotalPrice);
            //cmd.Parameters.AddWithValue("@ProductId", objSales.ProductId);
            //cmd.Parameters.AddWithValue("@CustomerId", objSales.CustomerId);
            //cmd.Parameters.AddWithValue("@EmployeeId", objSales.EmployeeId);
            //con.Open();
            //int rowCount = cmd.ExecuteNonQuery();
            //if (rowCount > 0)
            //{
            //    MessageBox.Show("Sales added successfully!", "Success", MessageBoxButtons.OK);
            //    ClearMethod();
            //}
            //else
            //{
            //    MessageBox.Show("Purchase Insertion failed!", "Failure", MessageBoxButtons.OK);
            //    ClearMethod();
            //}
            //con.Close();
            //LoadGridView();
            //ClearMethod();
        }

        private void cmbCustomer_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnReport_Click_1(object sender, EventArgs e)
        {
            List<SalesViewModel> list = new List<SalesViewModel>();
            using (SqlConnection con = new SqlConnection(conStr))
            {
                string SqlQuery = "SELECT pu.SaleId,pu.EmployeeId,pu.CustomerId,pu.ProductId,pu.VoucherNo,pu.SaleDate, pu.Quantity, pu.TotalPrice, po.ProductName, su.CustomerName,em.FullName,pu.ImageUrl FROM Sales pu JOIN Product po ON pu.ProductId=po.ProductId JOIN Customer su ON pu.CustomerId=su.CustomerId JOIN Employee em ON pu.EmployeeId=em.EmployeeId";
                SqlDataAdapter sda = new SqlDataAdapter(SqlQuery, con);
                DataTable dt = new DataTable();
                con.Open();
                sda.Fill(dt);
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    SalesViewModel objSales = new SalesViewModel();
                    objSales.ProductId = Convert.ToInt32(dt.Rows[i]["ProductId"].ToString());
                    objSales.CustomerId = Convert.ToInt32(dt.Rows[i]["CustomerId"].ToString());
                    objSales.EmployeeId = Convert.ToInt32(dt.Rows[i]["EmployeeId"].ToString());
                    objSales.VoucherNo = Convert.ToInt32(dt.Rows[i]["VoucherNo"].ToString());
                    objSales.SaleDate = Convert.ToDateTime(dt.Rows[i]["SaleDate"].ToString());
                    objSales.Quantity = Convert.ToInt32(dt.Rows[i]["Quantity"].ToString());
                    objSales.TotalPrice = Convert.ToDecimal(dt.Rows[i]["TotalPrice"].ToString());
                    objSales.ProductName = dt.Rows[i]["ProductName"].ToString();
                    objSales.CustomerName = dt.Rows[i]["CustomerName"].ToString();
                    objSales.FullName = dt.Rows[i]["FullName"].ToString();
                    objSales.ImageUrl = dt.Rows[i]["ImageUrl"].ToString();
                    objSales.SaleId = Convert.ToInt32(dt.Rows[i]["SaleId"].ToString());
                    list.Add(objSales);
                }
            }
            //using (Form1 form = new Form1(list))
            //{
            //    form.ShowDialog();
            //}

        }

       

        private void btnUpdate_Click_1(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(lblSaleId.Text))
            {
                Sales objSales = new Sales();
                decimal unitPrice = Convert.ToDecimal(txtUnitPrice.Text);
                objSales.CustomerId = Convert.ToInt16(cmbCustomer.SelectedValue);
                objSales.Quantity = Convert.ToInt16(txtQuantity.Text);
                objSales.TotalPrice = unitPrice * objSales.Quantity;
                objSales.EmployeeId = empId;
                objSales.VoucherNo = Convert.ToInt16(txtVoucherNo.Text);
                objSales.SaleDate = Convert.ToDateTime((dtpSaleDate.Text));
                objSales.SaleId = Convert.ToInt16(lblSaleId.Text);
                objSales.ProductId = Convert.ToInt16(cmbProductName.SelectedValue);
                objSales.ImageUrl = folderPath + Path.GetFileName(openFileDialog1.FileName);
                string sqlQuery = "UPDATE Sales SET SaleDate = @SaleDate, Quantity=@Quantity, CustomerId=@CustomerId,TotalPrice=@TotalPrice,EmployeeId=@EmployeeId,ProductId=@ProductId,ImageUrl=@ImageUrl WHERE SaleId=@SaleId";
                SqlConnection con = new SqlConnection(conStr);
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                if (filePath == "")
                {
                    cmd.Parameters.AddWithValue("@ImageUrl", imagePathFromData);
                }
                else
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@ImageUrl", objSales.ImageUrl);
                    try
                    {
                        File.Copy(filePath, Path.Combine(folderPath, Path.GetFileName(filePath)), true);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
                cmd.Parameters.AddWithValue("@VoucherNo", objSales.VoucherNo);
                cmd.Parameters.AddWithValue("@SaleDate", objSales.SaleDate);
                cmd.Parameters.AddWithValue("@Quantity", objSales.Quantity);
                cmd.Parameters.AddWithValue("@TotalPrice", objSales.TotalPrice);
                cmd.Parameters.AddWithValue("@ProductId", objSales.ProductId);
                cmd.Parameters.AddWithValue("@CustomerId", objSales.CustomerId);
                cmd.Parameters.AddWithValue("@EmployeeId", objSales.EmployeeId);
                cmd.Parameters.AddWithValue("@SaleId", objSales.SaleId);
                con.Open();
                int rowCount = cmd.ExecuteNonQuery();
                if (rowCount > 0)
                {
                    lblSaleId.Text = "";
                    MessageBox.Show("Sales Record added successfully!", "Success", MessageBoxButtons.OK);
                    ClearMethod();
                }
                else
                {
                    MessageBox.Show("Sales Record Insertion failed!", "Failure", MessageBoxButtons.OK);
                    ClearMethod();
                }
                con.Close();
                LoadGridView();
                ClearMethod();
            }
            else
            {
                MessageBox.Show("Please select Sale Id!", "Warning", MessageBoxButtons.OK);
            }
        }

        private void btnDelete_Click_1(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(lblSaleId.Text))
            {
                Sales objSales = new Sales();
                objSales.SaleId = Convert.ToInt16(lblSaleId.Text);
                string sqlQuery = "DELETE FROM  Sales WHERE SaleId=@SaleId";
                SqlConnection con = new SqlConnection(conStr);
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                cmd.Parameters.AddWithValue("@SaleId", objSales.SaleId);
                con.Open();
                int rowCount = cmd.ExecuteNonQuery();
                if (rowCount > 0)
                {
                    lblSaleId.Text = "";
                    MessageBox.Show("Deleted successfully!", "Success", MessageBoxButtons.OK);
                    ClearMethod();
                }
                else
                {
                    MessageBox.Show("Deletion failed!", "Failure", MessageBoxButtons.OK);
                    ClearMethod();
                }
                con.Close();
                LoadGridView();
                ClearMethod();
            }
            else
            {
                MessageBox.Show("Please select Purchase Id!", "Warning", MessageBoxButtons.OK);
            }
        }

        private void SalesManegement_Load(object sender, EventArgs e)
        {
            LoadEmployeeName();
            LoadComboproduct();
            LoadCombocustomer();
            pbProduct.Image = Resources.noimage;
            LoadGridView();
            btnHideImage.Visible = false;
        }

        private void dgvSale_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int cellId = e.RowIndex;
            try
            {
                DataGridViewRow row = dgvSale.Rows[cellId];
                lblSaleId.Text = row.Cells[0].Value.ToString();
                txtVoucherNo.Text = row.Cells[1].Value.ToString();
                dtpSaleDate.Text = row.Cells[2].Value.ToString();
                txtQuantity.Text = row.Cells[3].Value.ToString();
                decimal totalPrice = Convert.ToDecimal(row.Cells[4].Value.ToString());
                int quantity = Convert.ToInt32(row.Cells[3].Value.ToString());
                decimal unitPrice = totalPrice / quantity;
                txtUnitPrice.Text = unitPrice.ToString();
                cmbProductName.Text = row.Cells[5].Value.ToString();
                cmbCustomer.Text = row.Cells[6].Value.ToString();
                if (imagePathFromData == "No Image")
                {
                    pbProduct.Image = Resources.noimage;
                }
                byte[] data = (byte[])row.Cells[9].Value;
                MemoryStream stream = new MemoryStream(data);
                pbProduct.Image = Image.FromStream(stream);
                imagePathFromData = row.Cells[8].Value.ToString();
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
