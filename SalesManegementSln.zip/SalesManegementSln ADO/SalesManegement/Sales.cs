﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime;
using System.Text;
using System.Threading.Tasks;

namespace SalesManegement
{
    public class Sales
    {
        public int SaleId { get; set; }
        public int VoucherNo { get; set; }
        public DateTime SaleDate { get; set; }
        public int Quantity { get; set; }
        
        public decimal TotalPrice { get; set;}
        public string ImageUrl { get; set;}
        
        public int CustomerId { get; set;}
        public int EmployeeId { get; set;}
        public int ProductId { get; set;}


    }
}
