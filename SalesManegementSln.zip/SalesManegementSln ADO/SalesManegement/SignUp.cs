﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalesManegement
{
    public partial class SignUp : Form
    {
        Employee objEmployee = new Employee();
        string conStr = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
        string imageLocation = "";
        public SignUp()
        {
            InitializeComponent();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {

            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                imageLocation = openFileDialog.FileName.ToString();
                pbEmployee.Image = new Bitmap(openFileDialog.FileName);
            }
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            try
            {
                objEmployee.FullName = txtFullName.Text;
                objEmployee.EmpEmail = EmpEmail.Text;
                objEmployee.EmpPassword = EmpPassword.Text;
                objEmployee.EmpUserName = txtUserName.Text;
                objEmployee.ImagePath = imageLocation;
                SqlConnection con = new SqlConnection(conStr);
                string SqlQuery = "Insert into Employee values(@FullName,@EmpUserName,@EmpEmail,@EmpPassword,@ImagePath)";
                SqlCommand cmd = new SqlCommand(SqlQuery, con);
                cmd.Parameters.AddWithValue("@FullName", objEmployee.FullName);
                cmd.Parameters.AddWithValue("@EmpEmail", objEmployee.EmpEmail);
                cmd.Parameters.AddWithValue("@EmpPassword", objEmployee.EmpPassword);
                cmd.Parameters.AddWithValue("@EmpUserName", objEmployee.EmpUserName);
                cmd.Parameters.AddWithValue("@ImagePath", objEmployee.ImagePath);
                con.Open();
                int rowCount = cmd.ExecuteNonQuery();
                con.Close();
                if (rowCount > 0)
                {
                    MessageBox.Show("Registered Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Login objLogin = new Login();
                    this.Hide();
                    objLogin.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSignUphere_Click(object sender, EventArgs e)
        {
            Login objlogin = new Login();
            this.Hide();
            objlogin.ShowDialog();
        }
    }
}
