﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesManegement
{
    public class Employee
    {
        public int EmployeeId { get; set; }
        public string FullName { get; set; }
        public string EmpUserName { get; set; }
        public string EmpEmail { get; set; }
        public string EmpPassword { get; set; }
        public string ImagePath { get; set; }
    }
}
